print("Retornando somente as linhas que possuem a palavra Python")

arquivo = open('arquivo.txt', 'r')
contador = 0
for linha in arquivo:
	linha = linha.rstrip()
	if 'Python' in linha:
		contador = contador + 1
		print(linha)

print(f"Foram retornadas {contador} linhas")
arquivo.close()