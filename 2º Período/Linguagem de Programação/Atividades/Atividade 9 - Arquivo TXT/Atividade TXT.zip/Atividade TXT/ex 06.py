print("Criando e escrevendo em arquivos de texto (modo w).")

arquivo = open('arquivo2.txt', 'w')
arquivo.write("Felipe treinamentos\n")
arquivo.write("Criando um arquivo de texto com Python\n")
arquivo.write("Arquivo criado para a atividade do Professor Orlando\n")
arquivo.write("É isso aí pessoal!\n")
arquivo.close()


print("Texto criado.")
arquivo.close()

print("Lendo o que foi criado: ")
arquivo = open('arquivo2.txt', 'r')
for linha in arquivo:
    linha = linha.rstrip()
    print(linha)
arquivo.close()