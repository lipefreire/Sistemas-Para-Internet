#Abrindo o arquivo com o laço For

print("Abrindo arquivo de texto e mostrando seu conteúdo com o for:")

manipulador = open('arquivo.txt','r')
for linha in manipulador:
    linha = linha.rstrip()
    print(linha)

manipulador.close()